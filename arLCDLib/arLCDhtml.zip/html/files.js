var files =
[
    [ "ezLCDLib.cpp", "ez_l_c_d_lib_8cpp.html", "ez_l_c_d_lib_8cpp" ],
    [ "ezLCDLib.h", "ez_l_c_d_lib_8h.html", "ez_l_c_d_lib_8h" ]
];