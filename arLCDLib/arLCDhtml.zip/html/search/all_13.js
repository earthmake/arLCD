var searchData=
[
  ['verbose',['Verbose',['../classez_l_c_d3.html#a123a449ded6cad3d51d5a741e4d39cb2af9f819be8855dfd47043a7daa8e07f41',1,'ezLCD3']]],
  ['violet',['VIOLET',['../ez_l_c_d_lib_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba7088400e4fa72e2239115e7c0b294ea4',1,'ezLCDLib.h']]]
];
