var searchData=
[
  ['localbuffer',['localbuffer',['../classez_l_c_d3.html#a91471eb8fea6b3bd12da0586958bd892',1,'ezLCD3']]]
];
