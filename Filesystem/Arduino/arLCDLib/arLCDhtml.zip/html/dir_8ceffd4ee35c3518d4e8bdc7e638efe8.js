var dir_8ceffd4ee35c3518d4e8bdc7e638efe8 =
[
    [ "Segler", "dir_4d8d1218a72d5eb1320b7bc8e1d4ea46.html", "dir_4d8d1218a72d5eb1320b7bc8e1d4ea46" ]
];