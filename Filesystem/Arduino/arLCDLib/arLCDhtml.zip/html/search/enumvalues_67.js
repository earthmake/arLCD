var searchData=
[
  ['get_5fpixel',['Get_Pixel',['../classez_l_c_d3.html#a123a449ded6cad3d51d5a741e4d39cb2a6d0ccbffd0c6bc9da97ffcb608feacc2',1,'ezLCD3']]],
  ['getwidget_5fvalues',['GetWidget_Values',['../classez_l_c_d3.html#a123a449ded6cad3d51d5a741e4d39cb2af0d069abee7dbe0f82ba4155b5f8ca75',1,'ezLCD3']]]
];
